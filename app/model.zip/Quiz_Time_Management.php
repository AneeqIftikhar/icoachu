<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Quiz_Time_Management extends Model
{
    protected $table = 'Quiz_Time_Management';
    public $fillable = ['quiz_id','student_id','start_time','end_time'];
}
