<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sat_English extends Model
{
     protected $table = 'Sat_English';
    public $fillable = ['description'];
    public $timestamps = false;
}
